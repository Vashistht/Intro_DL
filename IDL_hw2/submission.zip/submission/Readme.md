# Used the following (attached here) for the structure of the code 

[pdf](HW1P1_S24_Writeup.pdf)